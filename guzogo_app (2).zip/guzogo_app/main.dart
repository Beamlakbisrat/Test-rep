import 'package:flutter/material.dart';
import 'package:guzogo_app/home_page.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: GuzogoHomePage(),
  ));
}